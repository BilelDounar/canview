import './asset/css/style.scss';

console.log('WebliPack Starter OK');
