<?php

session_start();
// require('vendor/autoload.php'); // if use composer
// require('pdo.php');
require('parameters.php');
require('core/func-base.php');
require('core/request.php');
require('core/validation.php');

