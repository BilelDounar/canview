<?php
require('../inc/function.php');

include('../view/header.php'); ?>

    <style>
        h1 {text-align: center;font-size: 3rem;margin: 3rem 0;}
        .logo {margin: 0 auto;max-width: 100px;}
        .logo img{width: 100%;}
    </style>

    <h1>WebliPack Starter</h1>
    <div class="logo">
        <img src="./asset/img/monster-weblipack.png" alt="logo weblitpack">
    </div>

<?php include('../view/footer.php');
