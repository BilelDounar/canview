<?php
header("HTTP/1.0 404 Not Found");
require('../inc/function.php');


include('../view/header.php'); ?>

    <style>
        h2 {text-align: center;margin: 3rem 0;}
    </style>
    <div>
        <h2>Page not Found - 404</h2>
    </div>

<?php include('../view/footer.php');
