<script src="./asset/dist/js/global.bundle.js"></script>

</body>
</html>
