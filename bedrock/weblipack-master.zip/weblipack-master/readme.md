### WebliPack

```
git clone
cd weblipack

// Effacer le dossier .git

// Initialisation d'un nouveau projet git
git init 

npm install

// webpack
npm run watch OR npm run build

// php
php -S localhost:2323 -t public
```
